package com.example.myspreadshirtapp

import androidx.lifecycle.ViewModel

class LoginPageViewModel : ViewModel() {
    // TODO: Implement the ViewModel
    val shopName:String = "Stefan's shop"
}