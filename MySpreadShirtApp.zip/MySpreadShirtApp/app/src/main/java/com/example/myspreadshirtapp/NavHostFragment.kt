package com.example.myspreadshirtapp

import androidx.fragment.app.Fragment

class NavHostFragment : Fragment(R.layout.fragment_nav_host) {
}